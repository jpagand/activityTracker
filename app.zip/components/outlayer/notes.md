## need test for

Check that text entity don't get added as Items

ignore
unignore
layoutItems does not layout ignored items

## To do

## docs

### methods you can overwrite

Outlayer._layoutItem( item )

Outlayer._resetLayout()

Outlayer._postLayout()

Outlayer._getContainerSize()

Outlayer._create()

Outlayer._manageStamp( stamp )

### Possibly

Outlayer.resize()

Outlayer.destroy()
