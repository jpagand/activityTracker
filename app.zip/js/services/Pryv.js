'use strict';

angular.module('tracker.pryv', [])
  .factory('Pryv', ['$rootScope', '$http', '$timeout', function($rootScope, $http, $timeout) {
    var host = 'pryv.io',
      streamId = "activity-tracker",
      requestingAppId = 'pryv-activity-tracker',
      requestedPermissions = [{"streamId" : streamId,
        "defaultName" : "Activity Tracker",
        "level" : "manage"}],
      defaultConfig = {withCredentials: true},
      Username, Token, ref, stopPoll = false;
    function processCallback(statusWanted, status, result, success, error) {
      if (!angular.isArray(statusWanted)) {
        statusWanted = [statusWanted];
      }
      if (statusWanted.indexOf(status) === -1) {
        if (angular.isFunction(error))
          error(result);
      } else {
        if (angular.isFunction(success)) {
          success(result)
        }
      }
    }
    function requestAppId(success, error) {
      var url = 'https://reg.' + host + '/access',
          config = angular.extend({}, defaultConfig, {requestingAppId: requestingAppId, requestedPermissions: requestedPermissions,languageCode: 'en', 'returnURL':false, headers: {'content/type': 'application/json'}});

      $http.post(url, config).success(function (result, status) {
        if (status === 201) {
          console.log(result);
          var popupUrl = result.url;
          if (window.plugins) {
            window.plugins.childBrowser.showWebPage(popupUrl, {showLocationBar: false, showAddress: false, showNavigationBar: false});
            window.plugins.childBrowser.onClose = function () {
              stopPoll = true;
            };
          }  else {
            ref =  window.open(popupUrl, '_blank', 'location=yes, width=305, height=360');
          }
          poll(result.poll, success, error);
        }
      }).error(function (result, status) {
          processCallback(201, status, result, success, error);
        })
    }
    function poll(pollUrl, success, error) {
      if (!stopPoll) {
        var  config = angular.extend({}, defaultConfig);
        $http.get(pollUrl, config).success(function (result, status) {
          console.log(result, ref);
          if (status === 200 || status === 304 || status === 201) {
            if (result.status === 'NEED_SIGNIN') {
              $timeout(function () {
                poll(result.poll, success, error)
              }, result.poll_rate_ms);
            } else if (result.status === 'ACCEPTED') {
              if (window.plugins) {
                window.plugins.childBrowser.close();
              }
              setCredential(result.username, result.token);
              processCallback(200, 200, {username: result.username, token: result.token}, success, error);
            } else {
              if (window.plugins) {
                window.plugins.childBrowser.close();
              }
              processCallback(200, 400, result, success, error);
            }
          }
        });
      }
    }
    function pull() {
      var lastPull = 0;
      if (localStorage) {
        lastPull = localStorage.getItem('lastPull') || 0;
      }
      getStreams(null, function (streams) {
        if (localStorage) {
          localStorage.setItem('activityTracker:streams', JSON.stringify(_.toArray(streams)));
        }
        getEvents({modifiedSince: lastPull, limit: 90000000}, function (events) {

        });
      })
    }
    function setCredential(username, token) {
      Username = username;
      Token = token;
      if (localStorage) {
        localStorage.setItem('username', username);
        localStorage.setItem('token', token);
      }
    }
    function logout() {
      Username = null;
      Token = null;
      if (localStorage) {
        localStorage.clear();
      }
    }
    function get (path, params, success, error) {
      if (!Username && !Token) {
        console.warn('GET',path, 'No credential');
      } else {
        params = angular.extend({auth: Token}, params);
        var  config = angular.extend({}, {params: params}, defaultConfig),
          url = 'https://' + Username + '.' + host + '/' + path;
      $http.get(url, config)
        .success(function (result, status) {
          processCallback([200, 301], status, result, success, error);
        })
        .error(function (result, status) {
          processCallback([200, 301], status, result, success, error);
        });
      }
    }
    function getStreams (params, success, error) {
      params = angular.extend({parentId: streamId}, params);
      get('streams', params, success, error);
    }
    function getEvents (params, success, error) {
      get('events', params, success, error);
    }
    return {
      getCredential: function () {
        if (localStorage) {
          Username = localStorage.getItem('username');
          Token = localStorage.getItem('token');
        }
        return {username: Username, token: Token};
      },
      login: requestAppId,
      logout: logout,
      getStreams: getStreams,
      getEvents: getEvents
    };
  }]);